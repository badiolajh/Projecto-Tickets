<?php $__env->startSection('content'); ?>

<h2 class="text-2xl font-bold text-gray-800 mb-6">
    Administración ⚙️
</h2>

<!-- CARDS -->
<div class="grid grid-cols-3 gap-6 mb-6">

    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-gray-500">Tickets Abiertos</p>
        <h3 class="text-2xl font-bold">15</h3>
    </div>

    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-gray-500">En Proceso</p>
        <h3 class="text-2xl font-bold">7</h3>
    </div>

    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-gray-500">Usuarios</p>
        <h3 class="text-2xl font-bold">10</h3>
    </div>

</div>

<!-- ACCIONES -->
<div class="grid grid-cols-2 gap-6">

    <a href="/admin/tickets" 
       class="bg-blue-500 text-white p-6 rounded-xl shadow hover:bg-blue-600 transition">
        📋 Gestionar Tickets
    </a>

    <a href="/admin/users/create" 
       class="bg-green-500 text-white p-6 rounded-xl shadow hover:bg-green-600 transition">
        ➕ Agregar Usuario
    </a>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zurielramirez/Desktop/NuevoProjecto/Projecto-Tickets/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>