<?php $__env->startSection('content'); ?>

<h2 class="text-2xl font-bold mb-6">Gestión de Tickets</h2>

<div class="bg-white p-4 rounded-xl shadow">

    <!-- BUSCADOR -->
    <div class="flex justify-between mb-4">
        <input placeholder="Buscar ticket..." class="border p-2 rounded w-1/3">
    </div>

    <!-- TABLA -->
    <table class="w-full text-sm">

        <thead class="bg-gray-100">
            <tr>
                <th class="p-3">Folio</th>
                <th class="p-3">Empleado</th>
                <th class="p-3">Problema</th>
                <th class="p-3">Prioridad</th>
                <th class="p-3">Estado</th>
                <th class="p-3">Asignar</th>
            </tr>
        </thead>

        <tbody>

            <tr class="border-t hover:bg-gray-50">
                <td class="p-3">#001</td>
                <td class="p-3">Juan Pérez</td>
                <td class="p-3">No enciende PC</td>

                <!-- PRIORIDAD -->
                <td class="p-3">
                    <span class="bg-red-500 text-white px-2 py-1 rounded">Alta</span>
                </td>

                <!-- ESTADO -->
                <td class="p-3">
                    <span class="bg-yellow-400 px-2 py-1 rounded">Abierto</span>
                </td>

                <!-- ASIGNAR TECNICO -->
                <td class="p-3">
                    <select class="border p-2 rounded">
                        <option>Asignar técnico</option>
                        <option>Técnico 1</option>
                        <option>Técnico 2</option>
                    </select>
                </td>
            </tr>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zurielramirez/Desktop/NuevoProjecto/Projecto-Tickets/resources/views/admin/tickets.blade.php ENDPATH**/ ?>